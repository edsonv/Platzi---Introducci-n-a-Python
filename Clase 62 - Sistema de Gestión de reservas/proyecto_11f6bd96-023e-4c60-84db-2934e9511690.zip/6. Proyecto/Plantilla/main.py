import asyncio
from hotel_management.reservations import Reservation, ReservationSystem
from hotel_management.customers import Customer, CustomerManagement
from hotel_management.rooms import Room, RoomManagement
from hotel_management.payments import process_payment
from datetime import datetime

async def main():
    # Inicializar sistemas

    # Crear habitaciones

    # Agregar clientes
    #customer1 = Customer(1, "Alice", "alice@example.com")
    #customer_mgmt.add_customer(customer1)

    # Verificar disponibilidad de habitaciones
    # Procesar pago asincrónicamente
    pass

if __name__ == "__main__":
    asyncio.run(main())

