class Room:
    def __init__():
        pass

class RoomManagement:
    def __init__(self):
        pass

    def add_room(self, room):
        """Agrega una nueva habitación al sistema."""
        pass

    def check_availability(self, room_number):
        """Verifica si una habitación está disponible."""
        pass
