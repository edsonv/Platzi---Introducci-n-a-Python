from collections import defaultdict
from datetime import datetime

class Reservation:
    def __init__():
        pass

class ReservationSystem:
    def __init__(self):
        pass

    def add_reservation(self, reservation):
        """Agrega una nueva reserva al sistema."""
        

    def cancel_reservation(self, reservation_id):
        """Cancela una reserva existente por ID."""
        pass


